/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package auladiego250425;

import javax.swing.JOptionPane;

/**
 *
 * @author diego.wsilva5
 */
public class AulaDiego250425 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       // String cpf = JOptionPane.showInputDialog(null,"Digite seu cpf");
       //String nome = JOptionPane.showInputDialog(null,"Digite seu nome");
       // JOptionPane.showMessageDialog(null, "Seu CPF é " + cpf + ", seu nome é " + nome);
       
       // for (int i = 0; i < 8; i++) {
            //JOptionPane.showMessageDialog(null,"repita");
            
        }
        
    }
    
}
