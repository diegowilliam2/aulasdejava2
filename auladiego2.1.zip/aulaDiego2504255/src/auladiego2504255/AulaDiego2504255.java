/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package auladiego2504255;

import javax.swing.JOptionPane;

/**
 *
 * @author diego.wsilva5
 */
public class AulaDiego2504255 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int opcao = JOptionPane.showConfirmDialog(null,"esta chovendo?");
        if (opcao == 0) {
            JOptionPane.showMessageDialog(null,"esta chovendo bastante");
        }
        else if (opcao == 1) {
                        JOptionPane.showMessageDialog(null,"nao esta chovendo");

        }
        else if (opcao == 2) {
                        JOptionPane.showMessageDialog(null,"cancelou");

        }
        else    {
                
        }
   
    }
    
}
